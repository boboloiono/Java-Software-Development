package hw6;

public interface IOperation {
	public String perform(String num1, String num2);
}
