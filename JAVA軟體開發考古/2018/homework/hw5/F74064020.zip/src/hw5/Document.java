package hw5;

public class Document {
	public String text;
	public Document() {}
	// Default constructor
	public String toString() {
		return text;
	}
	public void setText(String theSetText) {
		text = theSetText;
	}
}
